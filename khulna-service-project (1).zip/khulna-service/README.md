# Khulna Service

খুলনা শহরের মিস্ত্রি ও সেবাগ্রহীতাদের সংযুক্ত করার React + Firebase ভিত্তিক ওয়েব অ্যাপ।

## কী আছে

- বাংলা responsive UI, ক্যাটাগরি ও এলাকা অনুযায়ী মিস্ত্রি খোঁজা
- Firebase Email/Password Authentication, Worker / Customer role
- Worker profile, image upload, availability, service listing submission
- Customer job request এবং open job listing
- Admin custom claim-ভিত্তিক admin route ও pending listing moderation
- Firestore ও Storage security rules

> **গুরুত্বপূর্ণ:** এটি একটি কার্যকর starter implementation, কিন্তু production launch-এর আগে নিচের “Production checklist” সম্পন্ন করুন। এখানে payment, in-app chat, review workflow, favorites UI, phone OTP, advanced abuse/rate-limit service এবং পূর্ণ admin moderation analytics এখনো অন্তর্ভুক্ত নয়। কোনো বাস্তব কর্মী বা যাচাইকৃত পরিচয় ডেটা seed করা হয়নি।

## 1. Node.js ইনস্টল

Node.js-এর LTS সংস্করণ https://nodejs.org থেকে ইনস্টল করুন। এরপর terminal-এ যাচাই করুন:

```bash
node -v
npm -v
```

## 2. প্রজেক্ট ইনস্টল ও চালানো

```bash
npm install
cp .env.example .env
npm run dev
```

Windows PowerShell-এ `cp` কাজ না করলে:

```powershell
Copy-Item .env.example .env
```

`.env` ফাইলে Firebase web app-এর configuration বসান। `.env` কখনো GitHub-এ commit করবেন না।

## 3. Firebase project তৈরি

1. https://console.firebase.google.com খুলে Add project নির্বাচন করুন।
2. Project তৈরি হলে Project settings → General → Your apps → Web app যোগ করুন।
3. Firebase config থেকে API key, Auth domain, Project ID, Storage bucket, Messaging sender ID ও App ID কপি করে `.env`-এ বসান।
4. Authentication → Sign-in method → Email/Password enable করুন।
5. Firestore Database → Create database নির্বাচন করুন।
6. Storage → Get started নির্বাচন করুন।
7. Billing/plan ও region আপনার প্রয়োজন অনুযায়ী যাচাই করুন।

Firebase web config browser-এ ব্যবহারের জন্য; নিরাপত্তা Firestore/Storage rules এবং Authentication দিয়ে enforce করতে হবে। Admin service-account private key কখনো frontend বা public repository-তে রাখবেন না।

## 4. Firebase CLI ও rules deploy

```bash
npm install -g firebase-tools
firebase login
cp .firebaserc.example .firebaserc
```

`.firebaserc`-এ আপনার প্রকৃত Firebase project ID বসান। তারপর:

```bash
firebase deploy --only firestore:rules,storage
```

## 5. স্থানীয়ভাবে চালানো ও build

```bash
npm run dev
npm run build
npm run preview
```

Build error হলে terminal-এর সম্পূর্ণ error message দেখে সমাধান করুন।

## 6. প্রথম Admin নিরাপদে তৈরি

1. ওয়েবসাইটে সাধারণভাবে নিজের admin email দিয়ে Customer account তৈরি করুন।
2. Firebase Console → Authentication থেকে ওই email-এর UID যাচাই করুন।
3. নিরাপদ স্থানীয় মেশিনে Firebase Admin SDK সেটআপ করুন। Service-account JSON GitHub repository বা `src/`-এ রাখবেন না।
4. `scripts/set-admin.mjs` চালানোর আগে Firebase Admin SDK ইনস্টল করুন:

```bash
npm install firebase-admin
```

5. Service account JSON-এর path environment variable-এ দিন এবং script চালান:

```bash
# macOS/Linux
export GOOGLE_APPLICATION_CREDENTIALS="/secure/path/service-account.json"
node scripts/set-admin.mjs admin@example.com
```

```powershell
# Windows PowerShell
$env:GOOGLE_APPLICATION_CREDENTIALS="C:\secure\service-account.json"
node scripts/set-admin.mjs admin@example.com
```

6. Admin user sign out করে আবার sign in করবে। `/admin` route খুলে claim যাচাই করুন।
7. Admin account-এ শক্তিশালী password ও MFA ব্যবহার করুন। Service account key কখনো শেয়ার করবেন না।

Custom claim কেবল trusted Admin SDK environment থেকে set করা যাবে। ব্যবহারকারী নিজের Firestore profile edit করে Admin হতে পারবে না।

## 7. GitHub-এ আপলোড

```bash
git init
git add .
git commit -m "Initial Khulna Service app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/khulna-service.git
git push -u origin main
```

`.env`, service-account JSON, `node_modules`, `.firebase` commit করবেন না। `.gitignore` এগুলো বাদ দেয়।

## 8. Firebase Hosting deploy

```bash
npm run build
firebase deploy
```

Firebase Console → Hosting থেকে live URL পাবেন। GitHub Actions / Firebase Hosting GitHub integration ব্যবহার করতে চাইলে GitHub repository connect করুন এবং deployment secret-এ প্রয়োজনীয় credential নিরাপদে রাখুন।

## 9. Database collections

- `users/{uid}`: basic account profile and immutable role
- `workerProfiles/{uid}`: worker public profile and visibility
- `serviceListings/{listingId}`: worker service listings and moderation status
- `jobRequests/{jobId}`: customer work requests
- `reviews/{reviewId}`: review records (workflow extension required)
- `favorites/{favoriteId}`: favorite records (UI extension required)
- `categories/{categoryId}`: admin-managed categories

## 10. Production checklist

Before launch:
- Test every rule using Firebase Emulator Suite and Rules Unit Testing.
- Add App Check, server-side rate limiting / abuse protection and monitoring.
- Implement phone OTP only if the business requires it; current registration is email/password plus phone contact field.
- Add proper review eligibility: verify completed job ownership and enforce one review per job transactionally in trusted backend.
- Add favorites UI and secure deterministic favorite IDs.
- Add admin tools for user suspension, worker identity verification, category management, review moderation, and audit logs.
- Add server-side validation / Cloud Functions for state transitions; do not trust client-submitted statuses or prices.
- Add job assignment/completion workflow and worker/customer contact consent controls.
- Configure privacy policy, terms, support email/phone, data retention and account deletion.
- Test accessibility, mobile browsers, backups, indexes, quotas, billing alerts and disaster recovery.
- Do not claim a worker is identity-verified unless an authorized admin has actually checked documents.

## Troubleshooting

- `Firebase: Error (auth/operation-not-allowed)`: enable Email/Password provider.
- `Missing or insufficient permissions`: deploy rules and verify signed-in role/ownership.
- Storage upload failure: enable Storage and confirm file is JPG/PNG/WEBP under 5 MB.
- New Admin claim not visible: sign out and back in, or force-refresh the ID token.
- Blank page: check `.env` values and browser developer console.

## License

Choose and add a license before public distribution.
