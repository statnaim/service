/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { fontFamily: { bangla: ['Hind Siliguri', 'sans-serif'] }, colors: { brand: { 50:'#eff6ff',100:'#dbeafe',500:'#3b82f6',600:'#2563eb',700:'#1d4ed8',900:'#1e3a8a' } }, boxShadow: { soft:'0 12px 35px rgba(15, 35, 95, .08)' } } },
  plugins: [],
}