// Run locally with a Firebase service-account file kept OUTSIDE GitHub.
// Usage: GOOGLE_APPLICATION_CREDENTIALS=/absolute/path/service-account.json node scripts/set-admin.mjs user@example.com
import { initializeApp, applicationDefault } from 'firebase-admin/app'
import { getAuth } from 'firebase-admin/auth'
const email = process.argv[2]
if (!email) throw new Error('Usage: node scripts/set-admin.mjs user@example.com')
initializeApp({ credential: applicationDefault() })
const user = await getAuth().getUserByEmail(email)
await getAuth().setCustomUserClaims(user.uid, { admin: true })
console.log(`Admin claim set for ${email}. Sign out and sign in again to refresh token.`)