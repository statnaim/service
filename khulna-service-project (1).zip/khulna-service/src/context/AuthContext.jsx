import { createContext, useContext, useEffect, useState } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import { doc, getDoc } from 'firebase/firestore'
import { auth, db } from '../firebase/config'

const AuthContext = createContext(null)
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => onAuthStateChanged(auth, async current => {
    setUser(current)
    if (current) {
      try { const snap = await getDoc(doc(db, 'users', current.uid)); setProfile(snap.exists() ? snap.data() : null) }
      catch (e) { console.error(e); setProfile(null) }
    } else setProfile(null)
    setLoading(false)
  }), [])
  return <AuthContext.Provider value={{ user, profile, loading }}>{children}</AuthContext.Provider>
}
export const useAuth = () => useContext(AuthContext)