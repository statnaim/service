import { useEffect, useState } from 'react'
import { ArrowRight, Search, ShieldCheck, Users, Wrench } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { getWorkers } from '../services/data'
import { CATEGORIES } from '../utils/constants'
import WorkerCard from '../components/WorkerCard'

export default function Home() {
  const [workers,setWorkers] = useState([])
  const [category,setCategory] = useState('')
  const [area,setArea] = useState('')
  const navigate = useNavigate()
  useEffect(()=>{ getWorkers().then(setWorkers).catch(console.error) },[])
  return <div>
    <section className="overflow-hidden bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="container-page grid items-center gap-10 py-16 md:grid-cols-[1.1fr_.9fr] md:py-24">
        <div><span className="rounded-full bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-800">খুলনা শহরের স্থানীয় সেবা</span><h1 className="mt-6 text-4xl font-bold leading-tight text-slate-950 md:text-6xl">আপনার কাজের জন্য<br/><span className="text-brand-600">সঠিক মিস্ত্রি</span> খুঁজুন</h1><p className="mt-5 max-w-xl text-lg leading-8 text-slate-600">ইলেকট্রিশিয়ান, প্লাম্বার, রাজমিস্ত্রি থেকে শুরু করে নানা ধরনের দক্ষ কর্মী—সহজে খুঁজুন, যোগাযোগ করুন।</p>
          <div className="mt-8 flex flex-col gap-3 rounded-2xl border border-slate-100 bg-white p-3 shadow-soft sm:flex-row">
            <select className="field !border-0 !bg-slate-50" value={category} onChange={e=>setCategory(e.target.value)}><option value="">সেবার ধরন নির্বাচন</option>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select>
            <input className="field !border-0 !bg-slate-50" placeholder="এলাকা (যেমন: সোনাডাঙ্গা)" value={area} onChange={e=>setArea(e.target.value)}/>
            <button onClick={()=>navigate(`/workers?category=${encodeURIComponent(category)}&area=${encodeURIComponent(area)}`)} className="btn-primary"><Search size={18}/> খুঁজুন</button>
          </div>
          <div className="mt-6 flex flex-wrap gap-5 text-sm text-slate-500"><span className="flex items-center gap-2"><ShieldCheck size={17} className="text-green-600"/> প্রোফাইল যাচাইয়ের ব্যবস্থা</span><span className="flex items-center gap-2"><Users size={17} className="text-brand-600"/> স্থানীয় কর্মী</span></div>
        </div>
        <div className="relative"><div className="absolute -inset-5 rounded-[3rem] bg-blue-100/70 blur-2xl"/><div className="relative rounded-[2rem] bg-brand-700 p-8 text-white shadow-2xl"><div className="mb-10 flex items-center justify-between"><Wrench size={44}/><span className="rounded-full bg-white/15 px-4 py-2 text-sm">Khulna Service</span></div><div className="text-3xl font-bold leading-snug">দক্ষতা আছে?<br/>কাজ খুঁজুন এখানেই।</div><p className="mt-4 leading-7 text-blue-100">আপনার কাজের অভিজ্ঞতা, সার্ভিস ও মজুরি যুক্ত করে নতুন গ্রাহকের কাছে পৌঁছে যান।</p><Link to="/register?role=worker" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 font-bold text-brand-700">মিস্ত্রি হিসেবে যোগ দিন <ArrowRight size={18}/></Link></div></div>
      </div>
    </section>
    <section className="container-page py-16"><div className="mb-8 flex items-end justify-between"><div><p className="font-semibold text-brand-600">সেবা বিভাগ</p><h2 className="mt-1 text-3xl font-bold">কী ধরনের মিস্ত্রি প্রয়োজন?</h2></div><Link to="/workers" className="font-semibold text-brand-700">সব দেখুন →</Link></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">{CATEGORIES.map((c,i)=><Link key={c} to={`/workers?category=${encodeURIComponent(c)}`} className="rounded-2xl border border-slate-100 bg-white p-5 transition hover:-translate-y-1 hover:shadow-soft"><div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-xl">{['⚡','🚰','🧱','🎨','🪚','◻️','❄️','🔧','🪟','🧹','🏠','🛠️'][i]}</div><div className="font-bold">{c}</div></Link>)}</div></section>
    <section className="bg-slate-50 py-16"><div className="container-page"><div className="mb-8 flex items-end justify-between"><div><p className="font-semibold text-brand-600">সাম্প্রতিক প্রোফাইল</p><h2 className="mt-1 text-3xl font-bold">কাজের জন্য প্রস্তুত মিস্ত্রি</h2></div><Link to="/workers" className="font-semibold text-brand-700">আরও মিস্ত্রি →</Link></div>{workers.length ? <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{workers.slice(0,6).map(w=><WorkerCard key={w.uid} worker={w}/>)}</div>:<div className="card py-12 text-center text-slate-500">এখনও কোনো অনুমোদিত মিস্ত্রি নেই। মিস্ত্রি হিসেবে নিবন্ধন করে শুরু করুন।</div>}</div></section>
    <section className="container-page grid gap-5 py-16 md:grid-cols-3">{[['১','অ্যাকাউন্ট তৈরি করুন','গ্রাহক বা মিস্ত্রি হিসেবে নিবন্ধন করুন।'],['২','প্রয়োজনীয় সেবা খুঁজুন','দক্ষতা, এলাকা ও মজুরি দেখে পছন্দ করুন।'],['৩','সরাসরি যোগাযোগ করুন','ফোন বা WhatsApp-এ কথা বলে কাজ ঠিক করুন।']].map(x=><div key={x[0]} className="card"><div className="text-3xl font-bold text-brand-600">{x[0]}</div><h3 className="mt-3 text-xl font-bold">{x[1]}</h3><p className="mt-2 text-slate-600">{x[2]}</p></div>)}</section>
  </div>
}