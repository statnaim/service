import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Hammer, Menu, UserRound, LogOut } from 'lucide-react'
import { signOut } from 'firebase/auth'
import { auth } from '../firebase/config'
import { useAuth } from '../context/AuthContext'
import { useState } from 'react'

export default function Layout({ children }) {
  const { user, profile } = useAuth()
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()
  const logout = async () => { await signOut(auth); navigate('/') }
  const links = [['/', 'হোম'], ['/workers', 'মিস্ত্রি খুঁজুন'], ['/jobs', 'কাজের বিজ্ঞপ্তি'], ['/about', 'আমাদের সম্পর্কে']]
  return <div className="min-h-screen">
    <header className="sticky top-0 z-30 border-b border-slate-100 bg-white/95 backdrop-blur">
      <div className="container-page flex h-[72px] items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2 text-xl font-bold text-brand-700"><span className="rounded-xl bg-brand-600 p-2 text-white"><Hammer size={21}/></span> খুলনা সার্ভিস</Link>
        <nav className="hidden items-center gap-7 md:flex">{links.map(([to,label])=><NavLink key={to} to={to} className={({isActive})=>`font-semibold ${isActive?'text-brand-700':'text-slate-600 hover:text-brand-700'}`}>{label}</NavLink>)}</nav>
        <div className="hidden items-center gap-2 md:flex">
          {user ? <><Link className="btn-outline !px-4 !py-2" to="/dashboard"><UserRound size={17}/>{profile?.name || 'ড্যাশবোর্ড'}</Link><button onClick={logout} className="btn-outline !px-3 !py-2" aria-label="লগআউট"><LogOut size={17}/></button></> : <><Link to="/login" className="font-semibold text-slate-600">লগইন</Link><Link to="/register" className="btn-primary !px-4 !py-2">নিবন্ধন করুন</Link></>}
        </div>
        <button className="md:hidden" onClick={()=>setOpen(!open)} aria-label="মেনু"><Menu/></button>
      </div>
      {open && <div className="container-page grid gap-3 pb-4 md:hidden">{links.map(([to,label])=><Link onClick={()=>setOpen(false)} key={to} to={to}>{label}</Link>)}<Link to={user?'/dashboard':'/login'}>{user?'ড্যাশবোর্ড':'লগইন / নিবন্ধন'}</Link></div>}
    </header>
    <main>{children}</main>
    <footer className="mt-20 bg-slate-950 py-12 text-slate-300"><div className="container-page grid gap-8 md:grid-cols-3">
      <div><div className="mb-3 text-xl font-bold text-white">খুলনা সার্ভিস</div><p className="max-w-sm text-sm leading-7">খুলনা শহরের দক্ষ মিস্ত্রি ও সেবাগ্রহীতাদের এক জায়গায় যুক্ত করার সহজ প্ল্যাটফর্ম।</p></div>
      <div><h3 className="mb-3 font-bold text-white">দ্রুত লিংক</h3><div className="grid gap-2 text-sm"><Link to="/workers">মিস্ত্রি খুঁজুন</Link><Link to="/jobs">কাজের বিজ্ঞপ্তি</Link><Link to="/register">মিস্ত্রি হিসেবে যোগ দিন</Link></div></div>
      <div><h3 className="mb-3 font-bold text-white">নীতিমালা</h3><div className="grid gap-2 text-sm"><Link to="/privacy">গোপনীয়তা নীতি</Link><Link to="/terms">ব্যবহারের শর্তাবলি</Link><Link to="/contact">যোগাযোগ</Link></div></div>
    </div><div className="container-page mt-8 border-t border-slate-800 pt-5 text-xs">© {new Date().getFullYear()} Khulna Service. সর্বস্বত্ব সংরক্ষিত।</div></footer>
  </div>
}