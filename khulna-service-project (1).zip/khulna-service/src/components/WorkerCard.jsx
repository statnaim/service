import { MapPin, Phone, Star, BriefcaseBusiness } from 'lucide-react'
import { Link } from 'react-router-dom'
import { money, phoneHref } from '../utils/constants'
export default function WorkerCard({ worker }) {
  return <article className="card flex flex-col">
    <div className="flex items-start gap-4">
      <img src={worker.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(worker.name||'Mistry')}&background=dbeafe&color=1d4ed8`} className="h-16 w-16 rounded-2xl object-cover" alt="প্রোফাইল"/>
      <div className="min-w-0 flex-1"><h3 className="truncate text-lg font-bold">{worker.name}</h3><p className="font-semibold text-brand-700">{worker.profession}</p><div className="mt-1 flex items-center gap-1 text-xs text-slate-500"><MapPin size={13}/>{(worker.areas||[]).join(', ') || 'খুলনা'}</div></div>
    </div>
    <div className="my-4 flex flex-wrap gap-2 text-xs"><span className={`rounded-full px-3 py-1 ${worker.availability==='Available'?'bg-green-50 text-green-700':'bg-amber-50 text-amber-700'}`}>{worker.availability==='Available'?'কাজ নিচ্ছেন':worker.availability==='Busy'?'ব্যস্ত':'কাজ নিচ্ছেন না'}</span><span className="rounded-full bg-slate-100 px-3 py-1 text-slate-600"><BriefcaseBusiness size={12} className="mr-1 inline"/>{worker.experience || 'অভিজ্ঞতা উল্লেখ নেই'}</span></div>
    <div className="mt-auto flex items-center justify-between border-t border-slate-100 pt-4"><div><div className="text-xs text-slate-500">দৈনিক মজুরি</div><div className="font-bold text-slate-900">{money(worker.dailyWage)}</div></div><div className="flex gap-2"><Link to={`/workers/${worker.uid}`} className="btn-outline !px-3 !py-2">বিস্তারিত</Link>{worker.showPhone && worker.phone && <a className="btn-primary !px-3 !py-2" href={phoneHref(worker.phone)} aria-label="কল করুন"><Phone size={16}/></a>}</div></div>
  </article>
}