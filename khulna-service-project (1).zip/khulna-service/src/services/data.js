import { addDoc, collection, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, updateDoc, where } from 'firebase/firestore'
import { db } from '../firebase/config'

export async function createUserProfile(uid, data) {
  await (await import('firebase/firestore')).setDoc(doc(db, 'users', uid), { ...data, uid, createdAt: serverTimestamp(), updatedAt: serverTimestamp() })
}
export async function saveWorkerProfile(uid, data) {
  const ref = doc(db, 'workerProfiles', uid)
  const old = await getDoc(ref)
  await (await import('firebase/firestore')).setDoc(ref, {
    ...data, uid, visibility: old.exists() ? old.data().visibility : 'pending',
    updatedAt: serverTimestamp()
  }, { merge: true })
}
export async function getWorkers() {
  const q = query(collection(db, 'workerProfiles'), where('visibility', '==', 'public'), limit(100))
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function createListing(data) {
  return addDoc(collection(db, 'serviceListings'), { ...data, status: 'pending', createdAt: serverTimestamp(), updatedAt: serverTimestamp() })
}
export async function getListings() {
  const snap = await getDocs(query(collection(db, 'serviceListings'), where('status', '==', 'approved'), limit(100)))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function createJob(data) {
  return addDoc(collection(db, 'jobRequests'), { ...data, status: 'Open', createdAt: serverTimestamp(), updatedAt: serverTimestamp() })
}
export async function getOpenJobs() {
  const snap = await getDocs(query(collection(db, 'jobRequests'), where('status', '==', 'Open'), limit(100)))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function updateListingStatus(id, status) {
  await updateDoc(doc(db, 'serviceListings', id), { status, updatedAt: serverTimestamp() })
}