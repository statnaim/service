export const CATEGORIES = [
  'ইলেকট্রিশিয়ান','প্লাম্বার','রাজমিস্ত্রি','রংমিস্ত্রি','কাঠমিস্ত্রি','টাইলস মিস্ত্রি',
  'এসি মেকানিক','ওয়েল্ডিং মিস্ত্রি','গ্লাস মিস্ত্রি','পরিচ্ছন্নতা কর্মী','ঘর মেরামত','অন্যান্য'
]
export const AREAS = ['সোনাডাঙ্গা','শিববাড়ি','খালিশপুর','দৌলতপুর','বয়রা','নিরালা','গল্লামারি','রূপসা','টুটপাড়া','অন্যান্য']
export const money = n => n ? `৳${Number(n).toLocaleString('bn-BD')}` : 'আলোচনা সাপেক্ষে'
export const phoneHref = p => `tel:${String(p || '').replace(/[^+0-9]/g,'')}`
export const waHref = p => `https://wa.me/${String(p || '').replace(/[^0-9]/g,'').replace(/^0/, '88')}`